import {createServer} from 'node:http';
import {randomBytes} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {authorizedRequest} from './security.mjs';
import {startCodex} from './codex.mjs';

const port=Number(process.env.TRANSMISSION_PORT || 47831);
const origin=`http://127.0.0.1:${port}`;
const token=randomBytes(32).toString('hex');
const codex=startCodex();
const html=readFileSync(new URL('./index.html',import.meta.url),'utf8').replace('__CSRF_TOKEN__',token);
const script=readFileSync(new URL('./client.js',import.meta.url));
const server=createServer(async(req,res)=>{
    res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");
    if(req.headers.host!==`127.0.0.1:${port}`){res.writeHead(403);res.end();return;}
    const path=new URL(req.url,origin).pathname;
    if(req.method==='GET' && path==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');res.end(html);return;}
    if(req.method==='GET' && path==='/client.js'){res.setHeader('Content-Type','text/javascript');res.end(script);return;}
    if(req.method!=='POST' || !authorizedRequest(req,origin,token)){res.writeHead(403);res.end();return;}
    res.setHeader('Content-Type','application/json');
    try{
        let body='';for await(const chunk of req){body+=chunk;if(Buffer.byteLength(body)>48000)throw new Error('Keep the writing request under 48 KB.');}
        const input=JSON.parse(body || '{}');let result;
        if(path==='/api/status')result=await codex.status();
        else if(path==='/api/login')result=await codex.login();
        else if(path==='/api/ask'){
            if(typeof input.prompt!=='string' || !input.prompt.trim())throw new Error('A writing request is required.');
            result={message:await codex.ask(input.prompt)};
        } else {res.writeHead(404);res.end('{}');return;}
        res.end(JSON.stringify(result));
    }catch(error){res.writeHead(400);res.end(JSON.stringify({error:error.message}));}
});
server.listen(port,'127.0.0.1',()=>console.log(`Transmission companion is ready: ${origin}`));
server.on('error',error=>{console.error(error.message);codex.close();process.exitCode=1;});
for(const event of ['SIGINT','SIGTERM'])process.on(event,()=>{codex.close();server.close();});
