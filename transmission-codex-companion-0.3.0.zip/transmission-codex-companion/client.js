const token=document.querySelector('[name=transmission-token]').content;
const params=new URLSearchParams(location.hash.slice(1));
const parentOrigin=params.get('origin'),channel=params.get('channel');
let connected=false,busy=false;
const $=id=>document.getElementById(id);
const validOrigin=value=>{try{const url=new URL(value);return url.origin===value && ['http:','https:'].includes(url.protocol);}catch{return false;}};
async function api(action,data={}){const r=await fetch(`/api/${action}`,{method:'POST',headers:{'Content-Type':'application/json','X-Transmission-Token':token},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw new Error(result.error);return result;}
const reply=data=>{if(window.opener && validOrigin(parentOrigin))window.opener.postMessage({source:'transmission-codex',channel,...data},parentOrigin);};
async function status(){try{const data=await api('status');$('status').textContent=data.connected?'Signed in to Codex with ChatGPT.':'Sign in to Codex to connect your writing companion.';$('login').hidden=data.connected;$('connect').disabled=!data.connected;if(connected)reply({type:'status',connected:data.connected});return data;}catch(e){$('error').textContent=e.message;}}
$('login').onclick=async()=>{try{$('login').disabled=true;const result=await api('login');const url=new URL(result.authUrl);if(url.protocol!=='https:' || !['chatgpt.com','auth.openai.com'].includes(url.hostname))throw new Error('Codex returned an unexpected sign-in address.');$('signin').href=url.href;$('signin').hidden=false;$('status').textContent='Complete sign-in, then click Check connection.';}catch(e){$('error').textContent=e.message;}finally{$('login').disabled=false;}};
$('refresh').onclick=status;
if(window.opener && validOrigin(parentOrigin) && /^[a-f0-9]{32}$/.test(channel || '')){$('pairing').hidden=false;$('site').textContent=parentOrigin;}
$('connect').onclick=async()=>{if(!(await status())?.connected)return;connected=true;$('connect').hidden=true;$('disconnect').hidden=false;$('status').textContent='Connected. Return to Transmission to write.';reply({type:'connected'});};
$('disconnect').onclick=()=>{connected=false;$('connect').hidden=false;$('disconnect').hidden=true;reply({type:'disconnected'});};
window.addEventListener('message',async event=>{
    if(!connected || event.origin!==parentOrigin || event.source!==window.opener || event.data?.channel!==channel || event.data?.source!=='transmission-editor')return;
    const {id,prompt,type}=event.data;if(type!=='ask' || typeof id!=='string' || typeof prompt!=='string')return;
    if(busy){reply({type:'result',id,error:'Codex is already writing. Wait for the current suggestion.'});return;}
    busy=true;$('activity').textContent='Working on your writing request…';
    try{const result=await api('ask',{prompt});if(connected)reply({type:'result',id,message:result.message});$('activity').textContent='Suggestion returned to your editor.';}
    catch(e){reply({type:'result',id,error:e.message});$('error').textContent=e.message;}
    finally{busy=false;}
});
window.addEventListener('beforeunload',()=>reply({type:'disconnected'}));
void status();
