export function authorizedRequest(req,expectedOrigin,expectedToken){
    return req.headers.host===new URL(expectedOrigin).host && req.headers.origin===expectedOrigin && req.headers['x-transmission-token']===expectedToken && req.headers['content-type']==='application/json';
}
