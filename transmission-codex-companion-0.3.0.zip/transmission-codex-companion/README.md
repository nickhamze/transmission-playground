# Transmission Codex companion

A local connection between Transmission and Codex's supported app-server protocol. Requires Node.js 22 or newer. No API key is required: sign in with your ChatGPT account.

```sh
npm install
npm start
```

Keep the terminal running. In Transmission, choose **Codex on this computer → Connect Codex**. The companion opens at `http://127.0.0.1:47831`. If you already use Codex on this computer, its existing ChatGPT sign-in is reused. Otherwise, choose **Sign in with ChatGPT**, follow **Continue sign-in**, and click **Check connection** afterward. Click **Connect this editor**, then return to Transmission and ask for help. Keep the companion window open. Close it or click Disconnect to sever the editor connection.

Login credentials are managed by Codex; they are never returned to the WordPress editor or stored in WordPress. The companion deliberately does not provide a logout action, because the sign-in may be shared with the user's Codex CLI. Use Codex itself to change accounts.

The server binds only to loopback, validates the Host and Origin headers, requires a per-process request token, disables cross-origin API access and framing, and accepts only status/login/writing operations. The paired browser window checks the exact opener, origin and random session channel before accepting messages. Pairing lasts for the current window only. Treat all editors on the same origin as trusted; this is not a boundary against malicious scripts already running in your WordPress admin.

Writing uses ephemeral Codex threads, read-only sandboxing, disabled shell/code-mode/apps/plugins/MCP tools, no web search, and no approval execution. No WordPress mutation tools are exposed. The editor receives plain text and requires an explicit Apply action. A single request runs at a time with a three-minute timeout. Closing the editor stops delivery; an already-started inference may finish and consume normal Codex usage.

The bundled Codex CLI version is pinned in package.json. App-server integration is experimental; account availability, usage limits, and compatibility depend on Codex. A browser-only Playground cannot run Node: this companion must run on the tester's own computer. Popup blockers or browser cross-origin opener restrictions may require opening the demo in a normal browser tab.
