<?php
/**
 * Plugin Name: Transmission
 * Description: A quiet writing desk for WordPress, built for OpenStation.
 * Version: 0.3.0
 * Requires Plugins: desktop-mode
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 * Text Domain: transmission
 */
defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
    if ( ! function_exists( 'openstation_register_window' ) || ! current_user_can( 'edit_posts' ) ) return;
    $base = plugin_dir_url( __FILE__ );
    wp_register_script( 'transmission', $base . 'build/transmission.js', array( 'openstation' ), '0.3.0', true );
    wp_register_style( 'transmission', $base . 'build/transmission.css', array(), '0.3.0' );
    openstation_register_window( 'transmission', array(
        'title' => __( 'Transmission', 'transmission' ), 'icon' => 'dashicons-edit-page',
        'template' => function () { echo '<div data-transmission></div>'; },
        'script' => 'transmission', 'style' => 'transmission',
        'width' => 1200, 'height' => 820, 'min_width' => 360, 'min_height' => 420,
        'placement' => 'dock', 'capabilities' => array( 'edit_posts' ), 'autofocus' => false,
        'config' => array(
            'restRoot' => esc_url_raw( rest_url( 'wp/v2/' ) ),
            'restNonce' => wp_create_nonce( 'wp_rest' ),
            'siteName' => get_bloginfo( 'name' ), 'userId' => get_current_user_id(),
            'canPublish' => current_user_can( 'publish_posts' ),
            'canUpload' => current_user_can( 'upload_files' ),
            'adminUrl' => esc_url_raw( admin_url() ),
        ),
    ) );
    if ( function_exists( 'openstation_register_icon' ) ) {
        openstation_register_icon( 'transmission', array(
            'title' => __( 'Transmission', 'transmission' ), 'icon' => 'dashicons-edit-page',
            'icon_svg' => file_get_contents( __DIR__ . '/assets/transmission.svg' ),
            'position' => 24,
            'window' => 'transmission', 'capabilities' => array( 'edit_posts' ),
        ) );
    }
}, 30 );

// Core supplies the media models, uploader, attachment fields, styles and templates.
add_action( 'openstation_mode_init', function () {
    if ( current_user_can( 'edit_posts' ) ) wp_enqueue_media();
} );
