<?php
/**
 * Plugin Name: Transmission
 * Description: A quiet writing desk for WordPress, built for OpenStation.
 * Version: 0.5.0
 * Requires Plugins: desktop-mode
 * Requires PHP: 8.0
 * License: GPL-2.0-or-later
 * Text Domain: transmission
 */
defined( 'ABSPATH' ) || exit;

function transmission_register_app() {
    if ( ! function_exists( 'openstation_register_window' ) || ! current_user_can( 'edit_posts' ) ) return;
    $base = plugin_dir_url( __FILE__ );
    wp_register_script( 'transmission', $base . 'build/transmission.js', array( 'openstation', 'wp-block-editor', 'wp-block-library', 'wp-blocks', 'wp-element', 'wp-components', 'wp-data', 'wp-core-data', 'wp-format-library', 'wp-media-utils' ), '0.5.0', true );
    wp_register_style( 'transmission', $base . 'build/transmission.css', array( 'wp-components', 'wp-block-editor', 'wp-edit-blocks', 'wp-format-library' ), '0.5.0' );
    openstation_register_window( 'transmission', array(
        'title' => __( 'Transmission', 'transmission' ), 'icon' => 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( __DIR__ . '/assets/transmission.svg' ) ),
        'template' => function () { echo '<div data-transmission></div>'; },
        'script' => 'transmission', 'style' => 'transmission', 'preload_script' => true,
        'width' => 1200, 'height' => 820, 'min_width' => 360, 'min_height' => 420,
        'placement' => 'none', 'capabilities' => array( 'edit_posts' ), 'autofocus' => false,
        'config' => array(
            'restRoot' => esc_url_raw( rest_url( 'wp/v2/' ) ),
            'restNonce' => wp_create_nonce( 'wp_rest' ),
            'siteName' => get_bloginfo( 'name' ), 'userId' => get_current_user_id(),
            'canPublish' => current_user_can( 'publish_posts' ),
            'canUpload' => current_user_can( 'upload_files' ),
            'adminUrl' => esc_url_raw( admin_url() ),
        ),
    ) );
    if ( function_exists( 'openstation_register_icon' ) ) {
        openstation_register_icon( 'transmission', array(
            'title' => __( 'Transmission', 'transmission' ), 'icon' => 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( __DIR__ . '/assets/transmission.svg' ) ),
            'icon_svg' => file_get_contents( __DIR__ . '/assets/transmission.svg' ),
            'position' => 24,
            'window' => 'transmission', 'capabilities' => array( 'edit_posts' ),
        ) );
    }
}
add_action( 'init', 'transmission_register_app', 30 );
// Cookie authentication for REST requests may finish after init. The desktop's
// shortcut list needs the same capability-gated registration in that request.
add_filter( 'rest_authentication_errors', function ( $result ) {
    if ( ! is_wp_error( $result ) ) transmission_register_app();
    return $result;
}, 110 );

// Core supplies the media models, uploader, attachment fields, styles and templates.
add_action( 'openstation_mode_init', function () {
    if ( ! current_user_can( 'edit_posts' ) ) return;
    wp_enqueue_media();
    wp_enqueue_script( 'transmission' );
    wp_enqueue_style( 'transmission' );
    $context = new WP_Block_Editor_Context( array( 'name' => 'transmission/editor' ) );
    $settings = get_block_editor_settings( array(), $context );
    wp_add_inline_script( 'transmission', 'window.transmissionEditorSettings = ' . wp_json_encode( $settings ) . ';', 'before' );
} );
