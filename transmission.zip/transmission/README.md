# Transmission

A simpler way to write ordinary WordPress posts inside OpenStation. Transmission is a separate desktop app: the existing Posts screen and WordPress editor remain intact. No custom tables or custom post type.

## Working features

- A native OpenStation app window and dedicated desktop icon. The launcher defaults to the desktop; OpenStation manages running windows and user navigation preferences.
- Standard WordPress Posts REST API with WordPress's permissions and revisions.
- WordPress core block-editor, block-library and format-library packages from the host installation. Paragraphs, headings, lists, quotes, links, images, galleries and files serialize as standard WordPress blocks.
- OpenStation theme tokens drive surfaces, text, borders, accents, fonts and controls; theme changes apply through CSS.
- Undo/redo for body edits, image insertion and explicit AI changes.
- The actual WordPress Media Library dialog: browse, upload, attachment details, insert media and choose a featured image. Other files are inserted as core file blocks.
- Core featured-image, category, tag, slug and excerpt fields.
- Draft autosave; WordPress autosave revisions for text changes to published posts. Publishing and updating the public version require explicit review.
- Browser recovery and explicit external-edit conflict errors.
- Focus mode, responsive panels, accessible named dialogs and visible save/connection states.
- AI suggestions through a local Codex companion or the site's OpenStation AI provider. Suggestions never publish a post and are only applied explicitly.

## Codex sign-in

Download the companion package, install Node.js 22+, then run:

```sh
npm install
npm start
```

In Transmission select **Codex on this computer → Connect Codex**. Follow the companion's **Sign in with ChatGPT** flow if necessary, then **Connect this editor**. Keep the companion window and terminal open. The companion reuses an existing Codex ChatGPT sign-in and keeps credentials on your computer. It does not request an API key or expose credentials to WordPress.

The WordPress plugin itself contains no Node server. The companion is a separate local program. A plain browser Playground can run the editor but needs this companion on your own computer for Codex.

## Development

```sh
npm install
npm run dev -- --port 5186
npm test
npm run build
php -l transmission.php
npm run companion
node scripts/package.mjs
```

The localhost Vite page links to the real WordPress app and Playground. The editing engine is provided by WordPress, not duplicated in a standalone mockup.

## Current boundaries

Transmission uses WordPress’s standalone BlockEditorProvider and core formatting toolbar inside its own app shell. Existing block markup is parsed and serialized with core APIs. The inserter emphasizes writing blocks. Third-party blocks need their own editor scripts; use the regular WordPress editor for advanced plugin-specific layouts and controls. The writing canvas follows OpenStation’s appearance; it is not a pixel-perfect front-end theme preview.

The library currently shows the current author's latest 100 draft, pending and published posts. Selecting existing categories/tags is supported; creating terms, scheduling, revision comparison and site-rendered preview remain in the standard editor.

The pre-save modified timestamp check detects most conflicting edits, but is not an atomic collaboration lock. Published text changes use core autosaves; unpublished taxonomy/featured-image changes are held in browser recovery until Update. Recovery is plaintext local storage, isolated by site/user/post and offered for 24 hours. It is not a shared-device privacy boundary.

The local Codex app-server integration is experimental. It uses the pinned CLI in the companion package, disables configured external tools in that child process, and returns plain-text suggestions. Closing an editor prevents delivery but an already-started model request may finish and consume normal Codex usage.

See `design/ux-research.md` for the applied UX research and `design/validation.md` for evidence and remaining limitations.
